import sqlite3

def get_weather_for_city(city):
    conn = sqlite3.connect("weather.db")
    cursor = conn.cursor()

    cursor.execute("""
        SELECT city, temperature, description, humidity, timestamp
        FROM weather
        WHERE city = ?
        ORDER BY id DESC
        LIMIT 1
    """, (city,))

    row = cursor.fetchone()
    conn.close()
    return row

def list_available_cities():
    conn = sqlite3.connect("weather.db")
    cursor = conn.cursor()

    cursor.execute("SELECT DISTINCT city FROM weather ORDER BY city ASC")
    cities = [row[0] for row in cursor.fetchall()]

    conn.close()
    return cities

def main():
    print("Available cities:\n")
    for c in list_available_cities():
        print(" -", c)

    city = input("\nEnter a city name to view the latest weather: ").strip()

    record = get_weather_for_city(city)

    if record:
        print("\nLatest Weather:")
        print(f"City: {record[0]}")
        print(f"Temperature: {record[1]}°C")
        print(f"Description: {record[2]}")
        print(f"Humidity: {record[3]}")
        print(f"Timestamp: {record[4]}")
    else:
        print(f"\nNo weather data found for '{city}'. Run the ETL pipeline first.")

if __name__ == "__main__":
    main()
