# Weather ETL Pipeline

This project is a data engineering ETL pipeline that fetches current weather data for London, Paris, Berlin, and Zurich using the Open-Meteo API and loads it into a SQLite database.

## Prerequisites

- Python 3.x

## Setup

1. Clone or download this repository.
2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

## Running the Pipeline

Run the ETL pipeline:
```
python main.py
```

This will fetch the current weather for the specified cities and store it in `weather.db`.

## Database Schema

The SQLite database `weather.db` contains a table `weather` with the following columns:
- id: Primary key
- city: City name
- temperature: Temperature in Celsius
- description: Weather description
- humidity: Humidity percentage (may be NULL if not available)
- timestamp: ISO format timestamp of when the data was fetched