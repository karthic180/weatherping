import requests
import sqlite3
from datetime import datetime
import time

# ---------------------------------------------------------
# 1. List of major European cities (editable)
# ---------------------------------------------------------
EUROPEAN_CITIES = sorted([
    "Amsterdam", "Athens", "Belgrade", "Berlin", "Bern", "Bratislava",
    "Brussels", "Budapest", "Copenhagen", "Dublin", "Edinburgh",
    "Frankfurt", "Geneva", "Helsinki", "Istanbul", "Krakow", "Lisbon",
    "Ljubljana", "London", "Luxembourg", "Madrid", "Milan", "Munich",
    "Oslo", "Paris", "Porto", "Prague", "Reykjavik", "Riga", "Rome",
    "Sarajevo", "Sofia", "Stockholm", "Tallinn", "Valletta", "Vienna",
    "Vilnius", "Warsaw", "Zagreb", "Zurich"
])

# ---------------------------------------------------------
# 2. Get latitude & longitude for a city
# ---------------------------------------------------------
def geocode_city(city):
    url = f"https://geocoding-api.open-meteo.com/v1/search?name={city}&count=1"
    response = requests.get(url).json()

    if "results" not in response:
        return None, None

    result = response["results"][0]
    return result["latitude"], result["longitude"]

# ---------------------------------------------------------
# 3. Fetch weather data for a city
# ---------------------------------------------------------
def fetch_weather(city):
    lat, lon = geocode_city(city)
    if lat is None:
        print(f"⚠ Could not geocode {city}")
        return None

    weather_url = (
        f"https://api.open-meteo.com/v1/forecast?"
        f"latitude={lat}&longitude={lon}&current_weather=true"
    )

    data = requests.get(weather_url).json()
    current = data.get("current_weather", {})

    if not current:
        print(f"⚠ No weather data for {city}")
        return None

    return {
        "city": city,
        "temperature": current.get("temperature"),
        "description": current.get("weathercode"),
        "humidity": None,  # Open-Meteo free tier does not include humidity
        "timestamp": datetime.utcnow().isoformat()
    }

# ---------------------------------------------------------
# 4. Insert weather record into SQLite
# ---------------------------------------------------------
def load_to_db(record):
    conn = sqlite3.connect("weather.db")
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS weather (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            city TEXT,
            temperature REAL,
            description TEXT,
            humidity REAL,
            timestamp TEXT
        )
    """)

    cursor.execute("""
        INSERT INTO weather (city, temperature, description, humidity, timestamp)
        VALUES (?, ?, ?, ?, ?)
    """, (
        record["city"],
        record["temperature"],
        record["description"],
        record["humidity"],
        record["timestamp"]
    ))

    conn.commit()
    conn.close()

# ---------------------------------------------------------
# 5. Run ETL pipeline
# ---------------------------------------------------------
def run_pipeline():
    print("🌍 Starting European Weather ETL Pipeline...\n")

    for city in EUROPEAN_CITIES:
        print(f"➡ Fetching weather for {city}...")
        record = fetch_weather(city)

        if record:
            load_to_db(record)
            print(f"   ✔ Saved: {record['temperature']}°C (code {record['description']})")
        else:
            print(f"   ✖ Skipped {city}")

        time.sleep(0.5)  # avoid hammering API

    print("\n✅ ETL Pipeline completed successfully!")

# ---------------------------------------------------------
# Entry point
# ---------------------------------------------------------
if __name__ == "__main__":
    run_pipeline()
