import requests
import sqlite3
import json
from datetime import datetime

BASE_URL = 'https://api.open-meteo.com/v1/forecast'

city_coords = {
    'London': (51.5074, -0.1278),
    'Paris': (48.8566, 2.3522),
    'Berlin': (52.5200, 13.4050),
    'Zurich': (47.3769, 8.5417)
}

weather_descriptions = {
    0: "Clear sky",
    1: "Mainly clear",
    2: "Partly cloudy",
    3: "Overcast",
    45: "Fog",
    48: "Depositing rime fog",
    51: "Drizzle: Light",
    53: "Drizzle: Moderate",
    55: "Drizzle: Dense",
    56: "Freezing Drizzle: Light",
    57: "Freezing Drizzle: Dense",
    61: "Rain: Slight",
    63: "Rain: Moderate",
    65: "Rain: Heavy",
    66: "Freezing Rain: Light",
    67: "Freezing Rain: Heavy",
    71: "Snow fall: Slight",
    73: "Snow fall: Moderate",
    75: "Snow fall: Heavy",
    77: "Snow grains",
    80: "Rain showers: Slight",
    81: "Rain showers: Moderate",
    82: "Rain showers: Violent",
    85: "Snow showers slight",
    86: "Snow showers heavy",
    95: "Thunderstorm: Slight or moderate",
    96: "Thunderstorm with slight hail",
    99: "Thunderstorm with heavy hail"
}

cities = ['London', 'Paris', 'Berlin', 'Zurich']

def create_table():
    conn = sqlite3.connect('weather.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS weather (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            city TEXT,
            temperature REAL,
            description TEXT,
            humidity INTEGER,
            timestamp TEXT
        )
    ''')
    conn.commit()
    conn.close()

def fetch_weather(city):
    lat, lon = city_coords[city]
    params = {
        'latitude': lat,
        'longitude': lon,
        'current_weather': 'true',
        'hourly': 'relativehumidity_2m',
        'forecast_days': 1
    }
    response = requests.get(BASE_URL, params=params)
    if response.status_code == 200:
        data = response.json()
        current = data['current_weather']
        weathercode = current['weathercode']
        time = current['time']
        hourly_times = data['hourly']['time']
        hourly_humidity = data['hourly']['relativehumidity_2m']
        try:
            index = hourly_times.index(time)
            humidity = hourly_humidity[index]
        except ValueError:
            humidity = hourly_humidity[0] if hourly_humidity else None
        return {
            'city': city,
            'temperature': current['temperature'],
            'description': weather_descriptions.get(weathercode, "Unknown"),
            'humidity': humidity,
            'timestamp': datetime.now().isoformat()
        }
    else:
        print(f"Failed to fetch data for {city}: {response.status_code}")
        return None

def load_to_db(weather_data):
    conn = sqlite3.connect('weather.db')
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO weather (city, temperature, description, humidity, timestamp)
        VALUES (?, ?, ?, ?, ?)
    ''', (weather_data['city'], weather_data['temperature'], weather_data['description'], weather_data['humidity'], weather_data['timestamp']))
    conn.commit()
    conn.close()

def etl_pipeline():
    create_table()
    for city in cities:
        data = fetch_weather(city)
        if data:
            load_to_db(data)
            print(f"Loaded weather data for {city}")

if __name__ == '__main__':
    etl_pipeline()